<?php

/**
 * Description of Project_Model
 *
 * @author NaYeM
 */
class Supplier_model extends MY_Model
{

    public $_table_name;
    public $_order_by;
    public $_primary_key;


}
